package com.qoinpal.qoinpay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QoinPalApplication {

	public static void main(String[] args) {
		SpringApplication.run(QoinPalApplication.class, args);
	}

}
