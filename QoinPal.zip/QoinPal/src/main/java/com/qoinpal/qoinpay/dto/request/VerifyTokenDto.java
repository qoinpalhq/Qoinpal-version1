package com.qoinpal.qoinpay.dto.request;

import lombok.Data;

@Data
public class VerifyTokenDto {
    private String token;
}
