package com.qoinpal.qoinpay.Enum;

public enum Role {
    ROLE_USER, ROLE_ADMIN
}
