package com.qoinpal.qoinpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QoinPalApplicationTests {

	@Test
	void contextLoads() {
	}

}
